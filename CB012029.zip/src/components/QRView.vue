<template>
    <!-- component -->
<section class="">
    <div class="container mx-auto mt-10 flex max-w-3xl flex-wrap justify-center rounded-lg bg-white px-5 h-auto">
      <!-- QR Code Number Account & Uploadfile -->
      <div class="flex-wrap md:flex">
        <div class="mx-auto">
          <img class="mx-auto mt-12 h-52 w-52 rounded-lg border p-2 md:mt-0" src="https://i.imgur.com/FQS7fFC.png" alt="step" />
          <div>
            <h1 class="font-laonoto mt-4 text-center text-xl font-bold"></h1>
            <p class="mt-2 text-center font-semibold text-gray-600">QDFGE-EDSF-FSDF-FDED</p>
            <p class="mt-1 text-center font-medium text-red-500">ID : 040-12-00-01166166-001</p>
          </div>
          <!-- component -->
          <div class="mx-auto w-52">
            <div class="m-4">
              <div class="flex w-full items-center justify-center">
               
              </div>
            </div>
          </div>
          <button class="mx-auto block rounded-md border bg-blue-500 px-6 py-2 text-white outline-none">Download Voucher</button>
        </div>
        
      </div>
    </div>
  </section>
</template>