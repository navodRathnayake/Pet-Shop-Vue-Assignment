<script setup>
    import ProfileData from '../components/ProfileDataView.vue'
</script>

<template>
  <ProfileData />
</template>