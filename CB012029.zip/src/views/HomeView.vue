<script setup>
  import HomeComponent from '../components/HomeComponent.vue'
  import AboutUs from '../components/AboutUSComponent.vue'
  import RescueBanner from '../components/RescueBannerComponent.vue'
  import ContactUs from '../components/ContactUsComponent.vue'
</script>

<template>
  <HomeComponent />
  <!-- <AboutUs id="about" /> -->
  <!-- <RescueBanner /> -->
  <!-- <ContactUs /> -->
</template>
