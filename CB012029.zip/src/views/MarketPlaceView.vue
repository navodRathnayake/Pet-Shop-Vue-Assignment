<script setup>
import AppBar from '../components/AppBar.vue'
import MarketPlaceView from '../components/MarketPlaceView.vue'
</script>

<template>
  <div class="bg-white ">
    <AppBar />
    <MarketPlaceView />
  </div>
</template>
