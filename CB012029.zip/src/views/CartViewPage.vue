<template>
  <div class="mt-20">
    <AppBar />
    <CartContainer />
  </div>
</template>

<script setup>
  import AppBar from '../components/AppBar.vue'
  import CartContainer from '../components/CartView.vue'
</script>